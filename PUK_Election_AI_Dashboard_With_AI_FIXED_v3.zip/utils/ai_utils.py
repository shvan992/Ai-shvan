
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import re

# Initialize sentiment analyzer
analyzer = SentimentIntensityAnalyzer()

# Kurdish and Arabic-aware party detection
PARTY_KEYWORDS = {
    "PUK": ["PUK", "یەکێتی", "Talabani", "Pavel", "Bafel", "مام جلال", "Yeketi", "یەکێتی نیشتیمانی"],
    "KDP": ["KDP", "بارزانی", "پارتی", "Parastin", "PDK"],
    "Komal": ["Komal", "کۆمەڵ"],
    "Yekgirtu": ["Yekgirtu", "یەکگرتوو"],
    "Barey Gal": ["Barey Gal", "بەرەی گەل", "Lahur", "Lahur's party"],
    "Halwest": ["Halwest"]
}

def get_sentiment(text):
    score = analyzer.polarity_scores(text)["compound"]
    if score >= 0.05:
        return "Positive"
    elif score <= -0.05:
        return "Negative"
    else:
        return "Neutral"

def detect_party(text):
    text_lower = text.lower()
    found = []
    for party, keywords in PARTY_KEYWORDS.items():
        if any(kw.lower() in text_lower for kw in keywords):
            found.append(party)
    return ", ".join(found) if found else "Unknown"
