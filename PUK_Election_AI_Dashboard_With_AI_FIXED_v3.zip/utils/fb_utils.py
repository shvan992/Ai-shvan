
import requests
import re

def extract_post_id(url):
    try:
        # Handles most formats like /posts/, /permalink/, /photo?fbid=, etc.
        if "photo?fbid=" in url:
            return re.findall(r"fbid=(\d+)", url)[0]
        elif "/posts/" in url:
            return url.split("/posts/")[1].split("/")[0]
        elif "permalink/" in url:
            return url.split("permalink/")[1].split("/")[0]
        else:
            return re.findall(r"/(\d{10,})", url)[-1]
    except:
        return None

def fetch_comments(post_id, token, limit=10000):
    comments = []
    url = f"https://graph.facebook.com/v18.0/{post_id}/comments?access_token={token}&summary=true&filter=stream&limit=100"

    while url and len(comments) < limit:
        res = requests.get(url)
        if res.status_code != 200:
            break
        data = res.json()
        for item in data.get("data", []):
            comments.append(item.get("message", ""))
        url = data.get("paging", {}).get("next")
    return comments
